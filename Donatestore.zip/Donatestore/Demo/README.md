
#Customer Donate option - Magento 2.4.3 module

- php 7.4.33 


# Configuration:

To enable the donation option we should go through below configuration

- Stores -> Configuration -> Customer-Product Donate Option -> Configuration


